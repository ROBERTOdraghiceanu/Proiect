﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using TeamLID.TravelExperts.Repository.Domain;

namespace TeamLID.TravelExperts.App.Models.DataManager
{
    public class AdminManager
    {
        public static async Task<Admin> CompareLoginAdmin(string username, string password)
        {

            var context = new TravelExpertsContext();

            var admin = context.Admins.SingleOrDefault(c => c.AdminUserName == username);
            if (admin == null)
                return null;

            if (admin.AdminPassword == password)
                return admin;
            else
                return null;
        }
    }
}
