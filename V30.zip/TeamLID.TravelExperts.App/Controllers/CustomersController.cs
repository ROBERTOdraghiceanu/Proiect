﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TeamLID.TravelExperts.App.Models;
using TeamLID.TravelExperts.App.Models.DataManager;
using TeamLID.TravelExperts.Repository.Domain;

namespace TeamLID.TravelExperts.App.Controllers
{
    public class CustomersController : Controller
    {
        private readonly TravelExpertsContext _context;

        public CustomersController(TravelExpertsContext context)
        {
            _context = context;
        }

      
        [HttpGet]
        public ViewResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(UserViewModel user)
        {
            if (!ValidateUser(user))
            {
                ViewBag.msg = "validation failed, please fill in valid information and try again.";
                return View("Register", user);
            }
            else
            {
                var newCust = new Customers
                {
                    CustLastName = user.CustLastName,
                    CustFirstName = user.CustFirstName,
                    CustBusPhone = Regex.Replace(user.CustBusPhone, @"[-.]", ""),  // remove . and -
                    CustPostal = user.CustPostal.Replace('-', ' ').ToUpper(),  // T2G-1X6 => T2G 1X6
                    CustHomePhone = user.CustHomePhone != null ? Regex.Replace(user.CustHomePhone, @"[-.]", "") : null,
                    CustAddress = user.CustAddress,
                    CustCity = user.CustCity,
                    CustCountry = user.CustCountry,
                    CustEmail = user.CustEmail,
                    CustProv = user.CustProv.ToUpper(),  // ab => AB
                    Password = user.Password,
                    Username = user.Username
                };
                try
                {
                    await CustomerProfileManager.Add(newCust);
                    ViewBag.success = "Congratulations! Your account is active now, please log in.";
                    return View("Login");
                }
                catch (Exception e)
                {
                    ViewBag.msg = "username is already in use, please login.";
                    ViewBag.reason = e.InnerException.Message;  // sqlserver exception message, not very readable
                    return View("Register", user);
                }
            }
        }

        public async Task<IActionResult> Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel login)
        {
            var cust = await CustomerProfileManager.CompareLogin(login.username, login.password);

            if (cust != null)
            {
                HttpContext.Session.SetObject("login", cust);
                return RedirectToAction("CustomerHistory", new { customerId = cust.CustomerId });
            }
            else
            {
                ViewBag.msg = "Sorry, username or password is invalid.";
                return View("Login");
            }
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Remove("login");
            return View("Login");
        }

        public IActionResult Profile()
        {
            var loginCust = HttpContext.Session.GetObject<Customers>("login");

            if (loginCust == null)
                return View("Login");
            else
            {
                var id = loginCust.CustomerId;
                var profile = CustomerProfileManager.Find(id);

                return View(profile);
            }
        }

        public ActionResult CustomerHistory()
        {
            if (HttpContext.Session.GetObject<CustomerProfileManager>("login") != null)
            {


                var cust = HttpContext.Session.GetObject<Customers>("login");

                int id = cust.CustomerId;

                var bookings = BookingsManager.GetAllBookingsByCustomer(id)
                    .Select(bk => new BookingsModel
                    {
                        BookingId = bk.BookingId,
                        BookingDate = bk.BookingDate,
                        BookingNo = bk.BookingNo,
                        BookCount = bk.BookCount,
                        CustomerId = bk.Customer.CustFirstName,
                        TripTypeId = bk.TripType.Ttname,
                        PackageId = bk.Package.PkgName,
                    }).ToList();

                return View(bookings);


            }
            else
            {
                return View("Login");
            }
        }


        public ActionResult BookingDetail(int id)
        {
            var booking = BookingsManager.Find(id);

            var a = new BookingsModel
            {
                BookingId = booking.BookingId,
                BookingNo = booking.BookingNo,
                PkgStartDate = booking.Package.PkgStartDate,
                PkgEndDate = booking.Package.PkgEndDate,
                BookCount = booking.BookCount,
                CustomerId = booking.Customer.CustFirstName,
                TripTypeId = booking.TripType.Ttname,
                PkgDesc = booking.Package.PkgDesc,
                PackageId = booking.Package.PkgName,
            };

            return View(a);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var customers = await _context.Customers.FindAsync(id);
            if (customers == null)
            {
                return NotFound();
            }
            ViewData["AgentId"] = new SelectList(_context.Agents, "AgentId", "AgentId", customers.AgentId);
            return View(customers);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CustomerId,CustFirstName,CustLastName,CustAddress,CustCity,CustProv,CustPostal,CustCountry,CustHomePhone,CustBusPhone,CustEmail,AgentId,Username,Password")] Customers customers)
        {
            if (id != customers.CustomerId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(customers);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CustomersExists(customers.CustomerId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Profile));
            }
            ViewData["AgentId"] = new SelectList(_context.Agents, "AgentId", "AgentId", customers.AgentId);
            return View(customers);
        }

        private bool ValidateUser(UserViewModel user)
        {
            bool isValid = true;
            var phoneRegex = @"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$";
            var zipRegex = @"^[A-Za-z]\d[A-Za-z][-\ ]?\d[A-Za-z]\d$";

            if (user.CustLastName == "" || user.CustFirstName == "" ||
                user.Password != user.PasswordConfirm ||
                !Regex.IsMatch(user.CustBusPhone, phoneRegex) ||
                !Regex.IsMatch(user.CustPostal, zipRegex))
            {
                isValid = false;
            }

            return isValid;
        }


        public decimal TotalOwing(decimal amount)
        {
            decimal total = 0;

            total += amount;

            return total;
        }


        public async Task<IActionResult> Index()
        {
            var travelExpertsContext = _context.Customers.Include(c => c.Agent);
            return View(await travelExpertsContext.ToListAsync());
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var customers = await _context.Customers
                .Include(c => c.Agent)
                .FirstOrDefaultAsync(m => m.CustomerId == id);
            if (customers == null)
            {
                return NotFound();
            }

            return View(customers);
        }

        public IActionResult Create()
        {
            ViewData["AgentId"] = new SelectList(_context.Agents, "AgentId", "AgentId");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CustomerId,CustFirstName,CustLastName,CustAddress,CustCity,CustProv,CustPostal,CustCountry,CustHomePhone,CustBusPhone,CustEmail,AgentId,Username,Password")] Customers customers)
        {
            if (ModelState.IsValid)
            {
                _context.Add(customers);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["AgentId"] = new SelectList(_context.Agents, "AgentId", "AgentId", customers.AgentId);
            return View(customers);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var customers = await _context.Customers
                .Include(c => c.Agent)
                .FirstOrDefaultAsync(m => m.CustomerId == id);
            if (customers == null)
            {
                return NotFound();
            }

            return View(customers);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var customers = await _context.Customers.FindAsync(id);
            _context.Customers.Remove(customers);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CustomersExists(int id)
        {
            return _context.Customers.Any(e => e.CustomerId == id);
        }
    }
}

