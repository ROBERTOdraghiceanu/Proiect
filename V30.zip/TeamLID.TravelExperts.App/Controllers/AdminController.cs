﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TeamLID.TravelExperts.App.Models;
using TeamLID.TravelExperts.App.Models.DataManager;
using TeamLID.TravelExperts.Repository.Domain;

namespace Voyage.App.Controllers
{
    public class AdminController : Controller
    {
        public async Task<IActionResult> Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(AdminModel login)
        {
            var admin = await AdminManager.CompareLoginAdmin(login.AdminUserName, login.AdminPassword);

            if (admin != null)
            {
                HttpContext.Session.SetObject("login", admin);
                return RedirectToAction("Admin", new { AdminId = admin.AdminId });
            }
            else
            {
                ViewBag.msg = "Sorry, username or password is invalid.";
                return View("Login");
            }
        }
        public async Task<IActionResult> Admin()
        {
            return View();
        }
    }
}